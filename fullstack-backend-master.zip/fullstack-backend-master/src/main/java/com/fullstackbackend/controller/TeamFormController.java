package com.fullstackbackend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fullstackbackend.model.TeamForm;
import com.fullstackbackend.repository.TeamFormRepository;


@RestController
@CrossOrigin("http://localhost:3000")
public class TeamFormController {

	@Autowired
	private TeamFormRepository teamFormRepository;
	
	@PostMapping("/registrationForm")
    TeamForm newTeamForm(@RequestBody TeamForm newTeamForm) {
    	return teamFormRepository.save(newTeamForm);
    }
}
